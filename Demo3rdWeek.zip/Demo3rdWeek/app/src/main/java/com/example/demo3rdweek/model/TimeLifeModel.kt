package com.example.demo3rdweek.model

import com.example.demo3rdweek.R

data class TimeLifeModel(
    var name: String = "",
    var resourceImage: Int = R.drawable.profile_main_avatar,
    var content: String = "no content",
    var isLike: Boolean = false,
    var time: String = "00 : 00"
)