package com.example.demo3rdweek.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.demo3rdweek.R
import com.example.demo3rdweek.model.TimeLifeModel
import kotlinx.android.synthetic.main.item_time_life.view.*

class AdapterItemTimeLife : RecyclerView.Adapter<AdapterItemTimeLife.ViewHolder>() {
    var listTimeLife: ArrayList<TimeLifeModel> = ArrayList()
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): ViewHolder {
        val view = LayoutInflater.from(p0.context).inflate(R.layout.item_inbox_list, p0, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listTimeLife.size
    }

    fun setListData(list: ArrayList<TimeLifeModel>) {
        this.listTimeLife = list
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        val itemData = listTimeLife[i]
        viewHolder.itemView.imgAvatarTimeLife.setImageResource(itemData.resourceImage)
        viewHolder.itemView.tvNameLifeTime.text = itemData.name
        viewHolder.itemView.tvTimeTimeLife.text = itemData.time
        viewHolder.itemView.tvContentTimeLife.text = itemData.content
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
}